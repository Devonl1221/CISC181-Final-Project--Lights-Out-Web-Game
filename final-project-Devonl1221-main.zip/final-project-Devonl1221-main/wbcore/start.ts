import '../styles.css';
import { bootstrap } from '@gsilber/webez';

import { MainComponent } from '../src/app/main.component';
bootstrap<MainComponent>(MainComponent);
